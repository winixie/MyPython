==============================
Data Compression and Archiving
==============================

.. toctree::
    :maxdepth: 1

    bz2/index
    gzip/index
    tarfile/index
    zipfile/index
    zlib/index
