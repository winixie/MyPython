=================================
Generic Operating System Services
=================================

.. toctree::
    :maxdepth: 1
    
    os/index
    time/index
    getopt/index
    optparse/index
    argparse/index
    logging/index
    getpass/index
    platform/index

