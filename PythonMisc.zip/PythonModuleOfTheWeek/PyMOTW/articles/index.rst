################################
Features of the Standard Library
################################

This section of the PyMOTW guide includes feature-based introductions to several modules in the standard library, organized by what your goal might be.  Each article may include cross-references to several modules from different parts of the library, and show how they relate to one another.

.. toctree::
    :glob:
    
    *
