#!/usr/bin/env python
# encoding: utf-8
#
# Copyright (c) 2009 Doug Hellmann All rights reserved.
#
"""
"""

__version__ = "$Id: b.py 1 2010-04-23 12:11:22Z dhellmann $"
#end_pymotw_header

print 'running %s' % __file__
